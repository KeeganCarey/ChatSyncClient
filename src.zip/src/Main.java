

public class Main {
    public static String NAME = "Friend"; // replace this with your username or name
    public static String SERVER_ADDRESS = "4.tcp.ngrok.io";
    public static int PORT = 13430;

    public static char CHAT_KEY = '/'; // key used to open chat in game

    public static void main(String[] args) {
        try {
            Input test = new Input();

            test.pasteString("This is a test");
        } catch (Exception ignored) {}


    }
}